import { Router } from "express";
// import { catchErrors } from "../middlewares/catchErrors";
import * as authController from "../controllers/authController";

const authRouter = Router();

authRouter.post("/login", authController.loginUser);
authRouter.post("/register", authController.registerUser);
authRouter.post("/reset-password-request", authController.resetPasswordRequest);
authRouter.post("/reset-password", authController.resetPassword);

export { authRouter };
